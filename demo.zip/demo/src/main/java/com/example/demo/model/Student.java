package com.example.demo.model;

import javax.persistence.*;
import javax.persistence.Table;

@Entity
@Table(name = "Student")
public class Student {
		@Id
		@GeneratedValue
		private Long rollNumber;
		private String name;
		 private String gender;
		 private String grade;
	
		public Long getRollNumber() {
			return rollNumber;
		}
		public void setRollNumber(Long rollNumber) {
			this.rollNumber = rollNumber;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public String getGender() {
			return gender;
		}
		public void setGender(String gender) {
			this.gender = gender;
		}
		public String getGrade() {
			return grade;
		}
		public void setGrade(String grade) {
			this.grade = grade;
		}


}
