package com.example.demo.exception;

public class StudentNotFoundException extends Exception{
	
	private long book_id;
	
	public StudentNotFoundException(long student_id) {
		super(String.format("Student not found", student_id));
	}

}
