package com.example.demo.controller;

import java.util.HashMap;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import org.springframework.web.bind.annotation.RestController;

import com.example.demo.exception.StudentNotFoundException;
import com.example.demo.model.Student;
import com.example.demo.repository.StudentRepository;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@RestController
public class HelloController {
	@Autowired
	StudentRepository studentrepository;
	
	
	@SuppressWarnings("unchecked")
	@RequestMapping(value="/students", method=RequestMethod.POST)
	public String createdata(@Valid @RequestBody Student student) throws JsonProcessingException {
		Student save = studentrepository.save(student);
		HashMap m = new HashMap();
		m.put("class",save.getGrade());
		m.put("name", save.getName());
		m.put("gender", save.getGender());
		m.put("rollNumber", save.getRollNumber());
		ObjectMapper mapper = new ObjectMapper();
		String save2 = mapper.writeValueAsString(m);
		return save2;
		
	}
	
	@RequestMapping(value="/allstudents",method=RequestMethod.GET)
	public List<Student> getallstudents() {
		List<Student> student = studentrepository.findAll();
		return student;
		
	}
	
	@SuppressWarnings("unchecked")
	@RequestMapping(value="student/{id}",method = RequestMethod.GET)
	public String getbook(@PathVariable(value ="id")Long studentId) throws StudentNotFoundException, Exception {
		Student student = studentrepository.findById(studentId).orElseThrow(()->new StudentNotFoundException(studentId));
		HashMap m = new HashMap();
		m.put("class",student.getGrade());
		m.put("name", student.getName());
		m.put("gender", student.getGender());
		m.put("rollNumber", student.getRollNumber());
		ObjectMapper mapper = new ObjectMapper();
		String save2 = mapper.writeValueAsString(m);
		return save2;
		
	}

}
